
import React from 'react';
import { Simulator, SimulatorStatus } from '../types';
import { STATUS_COLORS } from '../constants';
import { Activity, Wrench, AlertCircle, Plane, Zap } from 'lucide-react';

interface SimulatorCardProps {
  simulator: Simulator;
  onClick?: () => void;
}

const SimulatorCard: React.FC<SimulatorCardProps> = ({ simulator, onClick }) => {
  const getIcon = () => {
    switch (simulator.status) {
      case SimulatorStatus.AVAILABLE: return <Activity className="w-5 h-5 text-emerald-500" />;
      case SimulatorStatus.IN_USE: return <Plane className="w-5 h-5 text-indigo-500" />;
      case SimulatorStatus.MAINTENANCE: return <Wrench className="w-5 h-5 text-amber-500" />;
      case SimulatorStatus.AOG: return <AlertCircle className="w-5 h-5 text-rose-500" />;
      default: return <Zap className="w-5 h-5 text-slate-400" />;
    }
  };

  const getStatusText = () => {
    return simulator.status.replace('_', ' ').toLowerCase();
  };

  return (
    <div 
      onClick={onClick}
      className="group relative bg-white rounded-[2rem] p-6 border border-slate-200 transition-all duration-500 hover:shadow-2xl hover:shadow-indigo-500/10 hover:-translate-y-1 cursor-pointer overflow-hidden"
    >
      {/* Decorative Background Element */}
      <div className={`absolute top-0 right-0 w-32 h-32 -mr-16 -mt-16 rounded-full opacity-5 transition-transform duration-700 group-hover:scale-150 ${STATUS_COLORS[simulator.status]}`}></div>

      <div className="flex justify-between items-start mb-6">
        <div className="space-y-1">
          <h4 className="text-xl font-bold text-slate-900 tracking-tight">{simulator.name}</h4>
          <div className="flex items-center gap-2">
            <span className={`w-2 h-2 rounded-full ${STATUS_COLORS[simulator.status]} ${simulator.status === SimulatorStatus.AVAILABLE ? 'status-pulse' : ''}`}></span>
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">{getStatusText()}</span>
          </div>
        </div>
        <div className="p-3 bg-slate-50 rounded-2xl group-hover:bg-indigo-50 transition-colors">
          {getIcon()}
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-end">
          <div className="space-y-1">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Reliability Index</p>
            <p className="text-lg font-black text-slate-800 leading-none">{simulator.metrics.reliability}%</p>
          </div>
          <div className="w-16 h-8 bg-slate-50 rounded-lg flex items-center justify-center overflow-hidden">
             {/* Simple Sparkline Mockup */}
             <svg className="w-full h-full" viewBox="0 0 100 40">
                <path d="M0,30 Q25,10 50,25 T100,15" fill="none" stroke="#4f46e5" strokeWidth="2" />
             </svg>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100 grid grid-cols-2 gap-4">
           <div>
             <p className="text-[9px] font-bold text-slate-400 uppercase">Engine Type</p>
             <p className="text-xs font-bold text-slate-700 truncate">{simulator.engineType}</p>
           </div>
           <div className="text-right">
             <p className="text-[9px] font-bold text-slate-400 uppercase">Serial No.</p>
             <p className="text-xs font-bold text-slate-700">{simulator.serialNumber}</p>
           </div>
        </div>
      </div>
      
      <div className="mt-6 flex items-center justify-between">
         <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">{simulator.location}</span>
         <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 text-indigo-600 font-bold text-[10px] uppercase">
           View Log <ChevronRight className="w-3 h-3" />
         </div>
      </div>
    </div>
  );
};

// Internal sub-component for icons
const ChevronRight = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7" /></svg>
);

export default SimulatorCard;
