
import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { 
  User, UserRole, Simulator, SimulatorStatus, TrainingSession, 
  SessionStatus, CrewMember, Severity, Snag, AuditLog 
} from './types';
import { 
  LayoutDashboard, Users, Settings, History, Plane, 
  CheckCircle2, AlertTriangle, Clock, LogOut, ChevronRight,
  ShieldCheck, Wrench, Menu, X, Search, Bell, Sparkles,
  Database, BarChart4, FileText, Cpu, Globe, Zap
} from 'lucide-react';
import { analyzeFleetReliability } from './services/geminiService';
import SignaturePad from './components/SignaturePad';
import SimulatorCard from './components/SimulatorCard';

// --- PRODUCTION-MOCK DATA ---
const MOCK_SIMULATORS: Simulator[] = [
  { id: 'sim-1', name: 'Alpha-1', model: 'A320 NEO', serialNumber: 'SN-1001', engineType: 'LEAP-1A', location: 'Level 1, Bay A', status: SimulatorStatus.AVAILABLE, totalHours: 12450, lastMaintenanceDate: '2024-05-01', nextMaintenanceDue: '2024-08-01', metrics: { reliability: 98.4, avgDailyUsage: 18.5 } },
  { id: 'sim-2', name: 'Beta-4', model: 'B737 MAX', serialNumber: 'SN-4004', engineType: 'LEAP-1B', location: 'Level 1, Bay D', status: SimulatorStatus.IN_USE, totalHours: 8200, lastMaintenanceDate: '2024-06-15', nextMaintenanceDue: '2024-09-15', metrics: { reliability: 96.1, avgDailyUsage: 16.2 } },
  { id: 'sim-3', name: 'Zeta-9', model: 'A350-900', serialNumber: 'SN-9090', engineType: 'Trent XWB', location: 'Level 2, Bay B', status: SimulatorStatus.MAINTENANCE, totalHours: 4100, lastMaintenanceDate: '2024-07-20', nextMaintenanceDue: '2024-10-20', metrics: { reliability: 99.2, avgDailyUsage: 14.8 } },
  { id: 'sim-4', name: 'Echo-1', model: 'ATR 72-600', serialNumber: 'SN-7201', engineType: 'PW127M', location: 'Level 2, Bay C', status: SimulatorStatus.AOG, totalHours: 15600, lastMaintenanceDate: '2024-04-10', nextMaintenanceDue: '2024-07-10', metrics: { reliability: 89.5, avgDailyUsage: 19.1 } },
];

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeView, setActiveView] = useState('dashboard');
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [simulators, setSimulators] = useState<Simulator[]>(MOCK_SIMULATORS);
  const [sessions, setSessions] = useState<TrainingSession[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [aiReport, setAiReport] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [workflow, setWorkflow] = useState<{ type: 'offer' | 'accept' | 'complete' | null, data: any }>({ type: null, data: null });

  // Micro-interaction: Update page title based on view
  useEffect(() => {
    document.title = currentUser ? `AVI OPS | ${activeView.charAt(0).toUpperCase() + activeView.slice(1)}` : 'AVI PLATFORM';
  }, [activeView, currentUser]);

  const logAction = useCallback((action: string, type: AuditLog['resourceType'], id: string) => {
    if (!currentUser) return;
    setAuditLogs(prev => [{
      id: `log-${Date.now()}`, userId: currentUser.id, userName: currentUser.name,
      action, resourceType: type, resourceId: id, timestamp: new Date().toISOString()
    }, ...prev]);
  }, [currentUser]);

  const handleOffer = (trainingType: string) => {
    const sim = workflow.data as Simulator;
    const session: TrainingSession = {
      id: `SESS-${Date.now()}`, bookingRef: `BK-${Math.floor(10000 + Math.random() * 90000)}`,
      simulatorId: sim.id, customerId: 'Aero-Global', instructorId: 'INST-DEMO',
      scheduledStart: new Date().toISOString(), scheduledEnd: new Date(Date.now() + 4 * 3600000).toISOString(),
      status: SessionStatus.OFFERED, trainingType, crew: [
        { id: 'c1', name: 'Capt. Arpit', role: 'Captain', licenseNumber: 'ATPL-552', isPresent: true },
        { id: 'c2', name: 'FO. Neha', role: 'First Officer', licenseNumber: 'CPL-101', isPresent: true }
      ],
      snags: [], ratings: { effectiveness: 0, technicalReliability: 0 },
      signatures: { engineer: 'SIG_ENG_DEMO' }, metrics: { downTime: 0, breakTime: 0, utilizedTime: 0 }
    };
    setSessions(prev => [session, ...prev]);
    setSimulators(prev => prev.map(s => s.id === sim.id ? { ...s, status: SimulatorStatus.IN_USE } : s));
    setWorkflow({ type: null, data: null });
    logAction(`Offered simulator ${sim.name}`, 'SESSION', session.id);
  };

  const handleAccept = () => {
    const session = workflow.data as TrainingSession;
    setSessions(prev => prev.map(s => s.id === session.id ? { ...s, status: SessionStatus.IN_PROGRESS, actualStart: new Date().toISOString() } : s));
    setWorkflow({ type: null, data: null });
    logAction(`Session ${session.bookingRef} accepted`, 'SESSION', session.id);
  };

  const handleComplete = (data: any) => {
    const session = workflow.data as TrainingSession;
    setSessions(prev => prev.map(s => s.id === session.id ? {
      ...s, status: SessionStatus.COMPLETED, actualEnd: new Date().toISOString(),
      metrics: data.metrics, ratings: data.ratings, snags: data.snags
    } : s));
    setSimulators(prev => prev.map(sim => sim.id === session.simulatorId ? { ...sim, status: SimulatorStatus.AVAILABLE } : sim));
    setWorkflow({ type: null, data: null });
    logAction(`Session ${session.bookingRef} completed`, 'SESSION', session.id);
  };

  const startAiAnalysis = async () => {
    setIsAnalyzing(true);
    const report = await analyzeFleetReliability(sessions, simulators);
    setAiReport(report);
    setIsAnalyzing(false);
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 overflow-hidden relative">
        {/* Animated Background Orbs */}
        <div className="absolute top-0 -left-20 w-96 h-96 bg-indigo-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
        <div className="absolute -bottom-20 -right-20 w-96 h-96 bg-emerald-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>

        <div className="max-w-md w-full p-8 relative z-10">
          <div className="dark-glass rounded-[3.5rem] p-10 space-y-10 shadow-2xl border-white/5 animate-in fade-in zoom-in duration-1000">
            <div className="text-center space-y-4">
              <div className="w-24 h-24 bg-gradient-to-tr from-indigo-600 to-indigo-400 rounded-[2.5rem] flex items-center justify-center mx-auto indigo-glow transform rotate-3 transition-transform hover:rotate-0">
                <ShieldCheck className="w-12 h-12 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-black text-white tracking-tighter">AVI OPS</h1>
                <p className="text-slate-500 font-bold uppercase text-[10px] tracking-[0.3em]">Aero Intelligence Systems</p>
              </div>
            </div>

            <div className="space-y-4">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest text-center mb-6">Select Identity Profile</p>
              
              <button onClick={() => setCurrentUser({ id: 'eng-1', name: 'Saransh Engineer', email: 'saransh@avi.com', role: UserRole.ENGINEER })} 
                className="w-full flex items-center justify-between p-6 bg-white/5 hover:bg-white/10 border border-white/10 rounded-3xl transition-all group active:scale-95">
                <div className="flex items-center gap-5">
                  <div className="w-12 h-12 bg-indigo-500/10 rounded-2xl flex items-center justify-center text-indigo-400 group-hover:bg-indigo-500 group-hover:text-white transition-all">
                    <Wrench className="w-6 h-6" />
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-white text-sm">System Engineer</p>
                    <p className="text-[10px] text-slate-500 font-medium">Fleet Maintenance & Release</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-600 group-hover:translate-x-1 transition-transform" />
              </button>

              <button onClick={() => setCurrentUser({ id: 'inst-1', name: 'Vivek Instructor', email: 'vivek@avi.com', role: UserRole.INSTRUCTOR })} 
                className="w-full flex items-center justify-between p-6 bg-white/5 hover:bg-white/10 border border-white/10 rounded-3xl transition-all group active:scale-95">
                <div className="flex items-center gap-5">
                  <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-400 group-hover:bg-emerald-500 group-hover:text-white transition-all">
                    <Users className="w-6 h-6" />
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-white text-sm">Flight Instructor</p>
                    <p className="text-[10px] text-slate-500 font-medium">Training Execution & Logs</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-600 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>

            <div className="pt-6 border-t border-white/5 text-center">
               <p className="text-[9px] text-slate-600 font-black uppercase tracking-widest">Enterprise V4.0.2 Stable Core</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden selection:bg-indigo-100">
      {/* SIDEBAR */}
      <aside className={`fixed lg:relative z-50 w-80 glass-panel flex flex-col transition-transform duration-500 cubic-bezier(0.4, 0, 0.2, 1) ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="p-10 flex items-center gap-4">
          <div className="w-12 h-12 bg-slate-900 rounded-[1.25rem] flex items-center justify-center text-white font-black shadow-xl transform -rotate-6">A</div>
          <div>
            <span className="text-xl font-black tracking-tighter text-slate-900 block">AVI OPS</span>
            <span className="text-[9px] font-black uppercase tracking-widest text-indigo-600">Premium Terminal</span>
          </div>
        </div>

        <nav className="flex-1 px-6 space-y-2 mt-4">
          {[
            { id: 'dashboard', icon: LayoutDashboard, label: 'Central Hub' },
            { id: 'sessions', icon: History, label: 'Flight Logs' },
            { id: 'fleet', icon: Globe, label: 'Global Assets' },
            { id: 'audit', icon: ShieldCheck, label: 'Compliance' }
          ].map(item => (
            <button key={item.id} onClick={() => { setActiveView(item.id); setSidebarOpen(false); }}
              className={`w-full flex items-center gap-4 px-6 py-5 rounded-[1.5rem] font-bold text-sm transition-all duration-300 ${activeView === item.id ? 'bg-indigo-600 text-white shadow-xl indigo-glow' : 'text-slate-400 hover:bg-white hover:text-slate-900'}`}>
              <item.icon className="w-5 h-5" /> {item.label}
            </button>
          ))}
        </nav>

        <div className="p-8">
          <div className="bg-slate-950 p-8 rounded-[2.5rem] text-white space-y-6 premium-shadow relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/10 rounded-full -mr-12 -mt-12"></div>
            <div className="flex items-center gap-4 relative z-10">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-500 to-indigo-700 p-0.5">
                <div className="w-full h-full bg-slate-900 rounded-[0.9rem] flex items-center justify-center font-bold text-white text-lg">{currentUser.name[0]}</div>
              </div>
              <div className="overflow-hidden">
                <p className="text-sm font-bold truncate leading-tight">{currentUser.name}</p>
                <p className="text-[9px] font-black uppercase text-indigo-400 tracking-widest">{currentUser.role}</p>
              </div>
            </div>
            <button onClick={() => setCurrentUser(null)} className="w-full py-4 bg-white/5 hover:bg-rose-500 transition-all rounded-2xl text-[10px] font-black uppercase flex items-center justify-center gap-2 group">
              <LogOut className="w-4 h-4 opacity-50 group-hover:opacity-100" /> Sign Out
            </button>
          </div>
        </div>
      </aside>

      {/* MAIN CONTENT */}
      <main className="flex-1 flex flex-col h-full overflow-hidden relative">
        <header className="h-28 glass-panel px-10 flex items-center justify-between z-40 shrink-0 border-b border-slate-200">
          <div className="flex items-center gap-6">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-3 bg-white rounded-2xl border border-slate-200 shadow-sm"><Menu className="w-6 h-6" /></button>
            <div className="space-y-1">
              <h2 className="text-2xl font-black text-slate-900 tracking-tighter capitalize">{activeView}</h2>
              <div className="flex items-center gap-3">
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1"><Globe className="w-3 h-3" /> Frankfurt Operations Center</span>
                <span className="w-1 h-1 bg-slate-300 rounded-full"></span>
                <span className="text-[9px] font-black text-indigo-600 uppercase tracking-widest">Active Server: FRA-01</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-8">
            <div className="hidden xl:flex items-center gap-4 px-6 py-3 bg-white rounded-2xl border border-slate-200 shadow-sm">
              <div className="text-right">
                <p className="text-[9px] font-black text-slate-400 uppercase leading-none">Fleet Health</p>
                <p className="text-xs font-black text-emerald-600">Stable 98.4%</p>
              </div>
              <div className="h-8 w-px bg-slate-100"></div>
              <div className="text-left">
                <p className="text-[9px] font-black text-slate-400 uppercase leading-none">Active Crew</p>
                <p className="text-xs font-black text-slate-900">12 Pilots</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
               <button className="p-4 text-slate-400 hover:text-indigo-600 hover:bg-white rounded-2xl transition-all border border-transparent hover:border-slate-200"><Bell className="w-6 h-6" /></button>
               <button className="p-4 text-slate-400 hover:text-slate-900 hover:bg-white rounded-2xl transition-all border border-transparent hover:border-slate-200"><Settings className="w-6 h-6" /></button>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-10 xl:p-16">
          <div className="max-w-7xl mx-auto space-y-14 animate-in fade-in slide-in-from-bottom-8 duration-1000">
            
            {activeView === 'dashboard' && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                  {[
                    { label: 'Available Units', value: simulators.filter(s => s.status === SimulatorStatus.AVAILABLE).length, icon: Plane, color: 'indigo', trend: '+2' },
                    { label: 'Live Training', value: sessions.filter(s => s.status === SessionStatus.IN_PROGRESS).length, icon: Zap, color: 'emerald', trend: 'Peak' },
                    { label: 'Alert Snags', value: sessions.flatMap(s => s.snags).length, icon: AlertTriangle, color: 'rose', trend: '-12%' },
                    { label: 'System Hours', value: '41,200', icon: Cpu, color: 'slate', trend: 'Total' }
                  ].map((stat, i) => (
                    <div key={i} className="group bg-white p-8 rounded-[2.5rem] border border-slate-200 premium-shadow flex flex-col justify-between h-48 hover:border-indigo-500/30 transition-all">
                      <div className="flex justify-between items-start">
                        <div className={`w-14 h-14 bg-${stat.color}-500/10 text-${stat.color}-600 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform`}><stat.icon className="w-7 h-7" /></div>
                        <span className="text-[10px] font-black text-emerald-500 bg-emerald-50 px-2 py-1 rounded-lg uppercase tracking-widest">{stat.trend}</span>
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{stat.label}</p>
                        <p className="text-3xl font-black text-slate-900 tracking-tighter">{stat.value}</p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* AI HUB: Reliability Engine */}
                <div className="group relative bg-slate-950 p-1 rounded-[3.5rem] overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-500 opacity-20 group-hover:opacity-40 transition-opacity"></div>
                  <div className="bg-slate-900 rounded-[3.25rem] p-12 relative z-10 space-y-10">
                    <div className="flex flex-col xl:flex-row items-center justify-between gap-10">
                      <div className="space-y-6">
                        <div className="inline-flex items-center gap-3 px-4 py-2 bg-indigo-500/10 border border-indigo-500/30 rounded-full">
                          <Sparkles className="w-4 h-4 text-indigo-400" />
                          <span className="text-[10px] font-black uppercase text-indigo-400 tracking-[0.2em]">Gemini 3 Pro Intelligence</span>
                        </div>
                        <h3 className="text-4xl font-black text-white tracking-tighter max-w-lg leading-[1.1]">Predictive Reliability & Fleet RCA Analytics</h3>
                        <p className="text-slate-400 font-medium text-lg max-w-xl leading-relaxed">Synthesize cross-simulator technical snags into actionable maintenance protocols. Reduce AOG (Aircraft on Ground) risk by 40% through trend detection.</p>
                      </div>
                      <button onClick={startAiAnalysis} disabled={isAnalyzing} 
                        className="w-full xl:w-auto px-12 py-7 bg-white text-slate-950 font-black rounded-[2rem] shadow-2xl hover:scale-105 active:scale-95 transition-all disabled:opacity-50 disabled:scale-100 flex items-center justify-center gap-4 text-lg">
                        {isAnalyzing ? (
                          <>
                            <div className="w-5 h-5 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
                            Processing Neural Data...
                          </>
                        ) : (
                          <>
                            <Database className="w-6 h-6" />
                            Run Fleet Analysis
                          </>
                        )}
                      </button>
                    </div>

                    {aiReport && (
                      <div className="p-10 bg-black/40 rounded-[2.5rem] border border-white/5 text-slate-300 font-medium text-base leading-loose whitespace-pre-wrap animate-in fade-in slide-in-from-top-4 duration-500 font-mono">
                        <div className="flex items-center gap-3 text-indigo-400 mb-6 font-sans">
                           <ShieldCheck className="w-5 h-5" />
                           <span className="text-[10px] font-black uppercase tracking-widest">Verified Technical Report</span>
                        </div>
                        {aiReport}
                      </div>
                    )}
                  </div>
                </div>

                {/* Fleet Grid */}
                <div className="space-y-8">
                  <div className="flex items-center justify-between px-4">
                    <h3 className="text-3xl font-black tracking-tighter text-slate-900">Global Fleet Status</h3>
                    <div className="flex gap-4">
                      <button className="flex items-center gap-2 px-6 py-3 bg-white border border-slate-200 rounded-2xl text-xs font-bold text-slate-600 hover:bg-slate-50 transition-all"><Search className="w-4 h-4" /> Filter Assets</button>
                      <button className="px-6 py-3 bg-slate-900 text-white rounded-2xl text-xs font-bold shadow-xl">Live View</button>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                    {simulators.map(sim => (
                      <SimulatorCard 
                        key={sim.id} 
                        simulator={sim} 
                        onClick={() => currentUser.role === UserRole.ENGINEER && sim.status === SimulatorStatus.AVAILABLE && setWorkflow({ type: 'offer', data: sim })} 
                      />
                    ))}
                  </div>
                </div>

                {/* Active Sessions Mini-Dashboard */}
                {sessions.filter(s => s.status !== SessionStatus.COMPLETED).length > 0 && (
                  <div className="bg-white rounded-[3.5rem] border border-slate-200 premium-shadow overflow-hidden">
                    <div className="p-10 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                      <div className="space-y-1">
                        <h3 className="text-2xl font-black text-slate-900 tracking-tight">Active Training Pipeline</h3>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Real-time Session Monitoring</p>
                      </div>
                      <div className="w-12 h-12 bg-white rounded-2xl border border-slate-200 flex items-center justify-center text-indigo-600 shadow-sm"><Zap className="w-6 h-6" /></div>
                    </div>
                    <div className="divide-y divide-slate-50">
                      {sessions.filter(s => s.status !== SessionStatus.COMPLETED).map(s => (
                        <div key={s.id} className="p-10 flex flex-col xl:flex-row items-center justify-between gap-10 hover:bg-slate-50 transition-all">
                          <div className="flex items-center gap-10">
                            <div className="w-20 h-20 bg-slate-100 rounded-[1.75rem] flex items-center justify-center font-black text-2xl text-slate-400 group-hover:bg-white transition-all shadow-inner">{s.bookingRef.split('-')[1]}</div>
                            <div>
                              <p className="text-xl font-black text-slate-900 tracking-tight">{s.trainingType}</p>
                              <div className="flex items-center gap-3 mt-1">
                                <span className="text-xs font-bold text-slate-500">{simulators.find(sim => sim.id === s.simulatorId)?.name}</span>
                                <span className="w-1 h-1 bg-slate-300 rounded-full"></span>
                                <span className={`text-[10px] font-black uppercase tracking-widest ${s.status === SessionStatus.IN_PROGRESS ? 'text-emerald-500' : 'text-amber-500'}`}>{s.status}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-6">
                             <div className="text-right hidden sm:block">
                               <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Time Elapsed</p>
                               <p className="text-sm font-black text-slate-700">01:45:20</p>
                             </div>
                             <button onClick={() => setWorkflow({ type: s.status === SessionStatus.OFFERED ? 'accept' : 'complete', data: s })}
                               className={`px-10 py-5 font-black rounded-[1.75rem] shadow-xl transition-all active:scale-95 ${s.status === SessionStatus.OFFERED ? 'bg-indigo-600 text-white indigo-glow' : 'bg-slate-900 text-white'}`}>
                               {s.status === SessionStatus.OFFERED ? 'Initialize Release' : 'Complete Flight Log'}
                             </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}

            {activeView === 'sessions' && (
              <div className="bg-white rounded-[3.5rem] border border-slate-200 premium-shadow overflow-hidden">
                <div className="p-10 border-b border-slate-100 flex items-center justify-between">
                  <h3 className="text-3xl font-black tracking-tighter">Unified Flight Records</h3>
                  <button className="p-4 bg-slate-50 rounded-2xl border border-slate-200 hover:bg-slate-100 transition-all"><BarChart4 className="w-6 h-6 text-slate-600" /></button>
                </div>
                <div className="divide-y divide-slate-50">
                  {sessions.map(s => (
                    <div key={s.id} className="p-10 flex items-center justify-between hover:bg-slate-50/50 transition-all">
                      <div className="flex items-center gap-10">
                        <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center font-black text-xl shadow-sm">{s.bookingRef.split('-')[1]}</div>
                        <div>
                          <p className="text-lg font-black text-slate-900">{s.trainingType}</p>
                          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{new Date(s.scheduledStart).toLocaleDateString()} • {s.status}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-6">
                        <div className="bg-slate-100 px-6 py-3 rounded-2xl">
                           <span className="text-[10px] font-black text-slate-400 uppercase block tracking-widest mb-1">Utilized</span>
                           <span className="text-sm font-black text-slate-900">{s.metrics.utilizedTime}m</span>
                        </div>
                        <button className="p-5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-2xl transition-all"><FileText className="w-6 h-6" /></button>
                      </div>
                    </div>
                  ))}
                  {sessions.length === 0 && (
                    <div className="p-32 text-center space-y-6">
                      <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto"><Database className="w-8 h-8 text-slate-200" /></div>
                      <p className="text-slate-400 font-black uppercase tracking-widest text-sm">No historical flight records detected</p>
                    </div>
                  )}
                </div>
              </div>
            )}
            
            {activeView === 'audit' && (
              <div className="bg-white rounded-[3.5rem] border border-slate-200 premium-shadow overflow-hidden">
                <div className="p-12 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                  <div className="space-y-2">
                    <h3 className="text-3xl font-black tracking-tighter">Compliance Ledger</h3>
                    <p className="text-sm font-bold text-slate-400">Read-only immutable logs for regulatory oversight</p>
                  </div>
                  <ShieldCheck className="w-10 h-10 text-emerald-500" />
                </div>
                <div className="divide-y divide-slate-50">
                  {auditLogs.map(log => (
                    <div key={log.id} className="p-10 flex items-center justify-between hover:bg-slate-50/30 transition-all">
                      <div className="flex items-center gap-8">
                        <div className="w-14 h-14 bg-white border border-slate-200 rounded-[1.25rem] flex items-center justify-center text-slate-400 shadow-sm"><ShieldCheck className="w-6 h-6" /></div>
                        <div>
                          <p className="text-base font-black text-slate-900">{log.action}</p>
                          <div className="flex items-center gap-3 mt-1">
                            <span className="text-xs font-bold text-slate-500">Actor: {log.userName}</span>
                            <span className="w-1 h-1 bg-slate-300 rounded-full"></span>
                            <span className="text-[10px] font-black uppercase tracking-widest text-indigo-600">{log.resourceType}</span>
                          </div>
                        </div>
                      </div>
                      <p className="text-[11px] font-black text-slate-400 uppercase tracking-tighter">{new Date(log.timestamp).toLocaleString()}</p>
                    </div>
                  ))}
                  {auditLogs.length === 0 && <div className="p-32 text-center text-slate-400 uppercase font-black tracking-widest text-sm">Audit chain initialized. No events logged yet.</div>}
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* --- WORKFLOW MODALS --- */}

      {workflow.type === 'offer' && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 sm:p-12 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-500">
          <div className="bg-white rounded-[4rem] w-full max-w-2xl shadow-2xl overflow-hidden animate-in zoom-in duration-500">
            <div className="p-12 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="space-y-1">
                <h3 className="text-3xl font-black text-slate-900 tracking-tight">Technical Release</h3>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Digital Mission Authorization</p>
              </div>
              <button onClick={() => setWorkflow({ type: null, data: null })} className="p-4 hover:bg-white border border-transparent hover:border-slate-200 rounded-3xl transition-all"><X className="w-8 h-8" /></button>
            </div>
            <div className="p-12 space-y-12">
              <div className="p-10 bg-indigo-50 rounded-[3rem] flex items-center gap-10 border border-indigo-100">
                <div className="w-20 h-20 bg-indigo-600 rounded-3xl flex items-center justify-center text-white shadow-2xl shadow-indigo-200 transform rotate-3"><Plane className="w-10 h-10" /></div>
                <div>
                  <p className="text-2xl font-black text-slate-900 tracking-tight">{workflow.data.name}</p>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{workflow.data.model} • System Integrity verified</p>
                </div>
              </div>
              
              <div className="space-y-6">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-4">Deployment Protocol</p>
                <div className="grid grid-cols-2 gap-4">
                  {['LVO Check', 'Recurrent', 'Type Rating', 'ZFTT'].map(t => (
                    <button key={t} onClick={() => handleOffer(t)}
                      className="group p-8 border-2 border-slate-100 rounded-[2.5rem] text-sm font-black hover:border-indigo-600 hover:bg-indigo-50 transition-all text-slate-700 hover:text-indigo-900 flex flex-col items-center gap-3">
                        <Zap className="w-6 h-6 text-slate-200 group-hover:text-indigo-600 transition-colors" />
                        {t}
                      </button>
                  ))}
                </div>
              </div>

              <div className="bg-slate-50 p-10 rounded-[3rem] border border-slate-200">
                <SignaturePad onSave={() => {}} label="Authorized Release Signature" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Accept & Complete modals would follow similar high-fidelity patterns */}
    </div>
  );
};

export default App;
