
import { SimulatorStatus, SessionStatus, Severity } from './types';

export const STATUS_COLORS = {
  [SimulatorStatus.AVAILABLE]: 'bg-emerald-500',
  [SimulatorStatus.AOG]: 'bg-rose-500',
  [SimulatorStatus.MAINTENANCE]: 'bg-amber-500',
  [SimulatorStatus.IN_USE]: 'bg-indigo-600',
  [SimulatorStatus.OFFLINE]: 'bg-slate-400',
};

export const TRAINING_TYPES = [
  'LVO Check',
  'Type Rating',
  'Recurrent Training',
  'Check Ride',
  'ZFTT',
  'Line Orientation'
];

export const SEVERITY_COLORS = {
  [Severity.CRITICAL]: 'text-rose-600 bg-rose-100',
  [Severity.HIGH]: 'text-orange-600 bg-orange-100',
  [Severity.MEDIUM]: 'text-amber-600 bg-amber-100',
  [Severity.LOW]: 'text-emerald-600 bg-emerald-100',
  [Severity.NONE]: 'text-slate-600 bg-slate-100',
};
