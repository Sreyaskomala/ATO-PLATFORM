
export enum UserRole {
  ADMIN = 'ADMIN',
  ENGINEER = 'ENGINEER',
  INSTRUCTOR = 'INSTRUCTOR',
  OPERATIONS = 'OPERATIONS',
  VIEWER = 'VIEWER'
}

export enum SimulatorStatus {
  AVAILABLE = 'AVAILABLE',
  IN_USE = 'IN_USE',
  MAINTENANCE = 'MAINTENANCE',
  AOG = 'AOG', 
  OFFLINE = 'OFFLINE'
}

export enum SessionStatus {
  SCHEDULED = 'SCHEDULED',
  OFFERED = 'OFFERED',
  READY = 'READY',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED'
}

export enum Severity {
  CRITICAL = 'CRITICAL',
  HIGH = 'HIGH',
  MEDIUM = 'MEDIUM',
  LOW = 'LOW',
  NONE = 'NONE'
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  lastLogin?: string;
}

export interface Simulator {
  id: string;
  name: string;
  model: string;
  serialNumber: string;
  engineType: string;
  location: string;
  status: SimulatorStatus;
  totalHours: number;
  lastMaintenanceDate: string;
  nextMaintenanceDue: string;
  metrics: {
    reliability: number;
    avgDailyUsage: number;
  }
}

export interface CrewMember {
  id: string;
  name: string;
  role: 'Captain' | 'First Officer' | 'Observer' | 'Student';
  licenseNumber: string;
  isPresent: boolean;
}

export interface Snag {
  id: string;
  sessionId: string;
  title: string;
  description: string;
  severity: Severity;
  timeLogged: string;
  isResolved: boolean;
  resolutionNotes?: string;
}

export interface TrainingSession {
  id: string;
  bookingRef: string;
  simulatorId: string;
  customerId: string;
  instructorId: string;
  scheduledStart: string;
  scheduledEnd: string;
  actualStart?: string;
  actualEnd?: string;
  status: SessionStatus;
  trainingType: string;
  crew: CrewMember[];
  snags: Snag[];
  ratings: {
    effectiveness: number;
    technicalReliability: number;
  };
  signatures: {
    engineer?: string;
    instructor?: string;
  };
  metrics: {
    downTime: number; 
    breakTime: number; 
    utilizedTime: number; 
  };
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  resourceType: 'SIMULATOR' | 'SESSION' | 'USER' | 'SYSTEM';
  resourceId: string;
  timestamp: string;
}
