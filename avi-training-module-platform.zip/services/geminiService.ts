
import { GoogleGenAI, Type } from "@google/genai";
import { Snag, Simulator, TrainingSession } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Uses Gemini 3 Pro to analyze complex technical snags across the fleet.
 */
export const analyzeFleetReliability = async (sessions: TrainingSession[], simulators: Simulator[]) => {
  const model = "gemini-3-pro-preview";
  
  const snagHistory = sessions
    .flatMap(s => s.snags)
    .map(sn => `[${sn.severity}] ${sn.title}: ${sn.description}`)
    .join('\n');

  const prompt = `Act as a Senior Flight Simulator Maintenance Engineer. 
  Analyze the following fleet data and technical snags:
  
  SIMULATORS:
  ${simulators.map(s => `- ${s.name} (${s.model}): Status ${s.status}, Hours ${s.totalHours}`).join('\n')}
  
  RECENT SNAGS:
  ${snagHistory}
  
  Provide a production-level technical report covering:
  1. Root Cause Analysis (RCA) of recurring issues.
  2. Critical maintenance priorities.
  3. Predictive failure warnings (which simulator is likely to go AOG next?).
  4. Suggested preventive actions.
  
  Keep the tone professional and data-driven.`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 4000 }
      }
    });
    return response.text;
  } catch (error) {
    console.error("AI Analysis Failed:", error);
    return "Could not generate fleet reliability report. Please check API status.";
  }
};

/**
 * Quick analysis for a single session completion.
 */
export const summarizeSessionTechnical = async (session: TrainingSession) => {
  const model = "gemini-3-flash-preview";
  const prompt = `Summarize the technical performance of session ${session.bookingRef}. 
  Utilized Time: ${session.metrics.utilizedTime} mins. 
  Down Time: ${session.metrics.downTime} mins.
  Snags: ${session.snags.map(s => s.description).join(', ')}
  Provide a 2-sentence technical summary for the engineering log.`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    return "Session summary unavailable.";
  }
};
